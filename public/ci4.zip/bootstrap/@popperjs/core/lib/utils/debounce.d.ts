export default function debounce<T>(fn: (...args: Array<any>) => any): () => Promise<T>;
